import { describe, expect, it, vi, beforeEach } from "vitest";

const resilientFetch = vi.fn();
const postJson = vi.fn();
const getJson = vi.fn();

vi.mock("./httpClient", () => ({
  resilientFetch: (...a: unknown[]) => resilientFetch(...a),
  postJson: (...a: unknown[]) => postJson(...a),
  getJson: (...a: unknown[]) => getJson(...a),
  getText: vi.fn(),
  isOffline: () => false,
}));

import { findPlaces, generateImage, webSearch } from "./http";
import type { HttpToolCtx } from "./http";
import * as quota from "../quota";

const ctx = (): HttpToolCtx =>
  ({
    config: {
      tier: "gemini",
      model: "gemini-3.6-flash",
      keys: { gemini: ["k"] },
      pinnedLocation: "",
    },
    location: { pinnedPlace: "", coords: async () => null },
  }) as unknown as HttpToolCtx;

describe("nearby places mirror recovery", () => {
  it("uses an independent working mirror when others fail or return malformed data", async () => {
    getJson.mockImplementation(async (url: string) => {
      if (url.startsWith("https://overpass.private.coffee/"))
        return {
          elements: [
            { lat: 19.2, lon: 72.8, tags: { name: "Test pharmacy", amenity: "pharmacy" } },
          ],
        };
      if (url.startsWith("https://overpass-api.de/")) throw new Error("HTTP 504");
      return { error: "unavailable" };
    });
    const config = ctx();
    config.location.coords = async () => ({ lat: 19.2, lon: 72.8, place: "Test location" });
    const result = await findPlaces("pharmacy", config);
    expect(result.ok).toBe(true);
    expect(result.summary).toContain("Test pharmacy");
    expect(getJson).toHaveBeenCalledTimes(3);
    getJson.mockReset();
  });
});

/** The live free-tier rejection: not a spent allowance — an allocation of zero. */
const LIMIT_ZERO = JSON.stringify({
  error: {
    code: 429,
    status: "RESOURCE_EXHAUSTED",
    message:
      "Quota exceeded for metric: generativelanguage.googleapis.com/" +
      "generate_content_free_tier_requests, limit: 0, model: gemini-2.5-flash-image",
  },
});

const rejected = (body: string, status = 429) => ({ ok: false, status, text: async () => body });
const drew = () => ({
  ok: true,
  status: 200,
  json: async () => ({
    candidates: [
      { content: { parts: [{ inline_data: { data: "AAA", mime_type: "image/png" } }] } },
    ],
  }),
});

const urlOf = (call: unknown[]) => String(call[0]);

beforeEach(() => {
  resilientFetch.mockReset();
  postJson.mockReset();
});

describe("generateImage — free tier allocates some image models nothing", () => {
  it("walks past a limit:0 model instead of failing the request on it", async () => {
    resilientFetch.mockResolvedValueOnce(rejected(LIMIT_ZERO)).mockResolvedValueOnce(drew());

    const r = await generateImage("a red fox", ctx());

    expect(r.ok).toBe(true);
    expect((r.data as { imageUrl?: string })?.imageUrl).toBe("data:image/png;base64,AAA");
    expect(resilientFetch).toHaveBeenCalledTimes(2);
    // Two DIFFERENT models — a retry of the same id would be refused identically.
    expect(urlOf(resilientFetch.mock.calls[0]!)).not.toBe(urlOf(resilientFetch.mock.calls[1]!));
  });

  it("never calls a zero-allocation quota 'used up' when every model refuses", async () => {
    resilientFetch.mockResolvedValue(rejected(LIMIT_ZERO));

    const r = await generateImage("a red fox", ctx());

    expect(r.ok).toBe(false);
    expect(r.summary).toMatch(/free tier/i);
    expect(r.summary).toMatch(/billing/i);
    // The bug this replaces: the raw 429 reached the chat model, which relayed it as
    // an exhausted allowance that would "free up" — it never will.
    expect(r.summary).not.toMatch(/used up|try again later|free up/i);
  });

  it("surfaces the API's own reason for a non-quota failure", async () => {
    resilientFetch.mockResolvedValue(
      rejected(JSON.stringify({ error: { message: "API key not valid" } }), 400),
    );

    expect((await generateImage("x", ctx())).summary).toMatch(/API key not valid/);
  });
});

describe("webSearch — the grounded call must leave room to answer", () => {
  it("sends no maxOutputTokens, so thinking can't eat the whole reply budget", async () => {
    postJson.mockResolvedValue({ candidates: [{ content: { parts: [{ text: "42" }] } }] });

    const r = await webSearch("who won", ctx());

    expect(r.ok).toBe(true);
    const body = JSON.parse(String(postJson.mock.calls[0]![1]));
    expect(body.generationConfig?.maxOutputTokens).toBeUndefined();
    expect(body.tools).toEqual([{ google_search: {} }]);
  });

  it("reports WHY an empty answer came back rather than a bare shrug", async () => {
    postJson.mockResolvedValue({ candidates: [{ finishReason: "MAX_TOKENS", content: {} }] });

    expect((await webSearch("who won", ctx())).summary).toMatch(/MAX_TOKENS/);
  });
});

describe("webSearch — grounds only where the free tier allows it", () => {
  const answer = { candidates: [{ content: { parts: [{ text: "Saturday 10am PT" }] } }] };
  const modelOf = (call: unknown[]) => String(call[0]).match(/models\/([^:]+):/)![1];
  const keyOf = (call: unknown[]) =>
    (call[2] as { headers: Record<string, string> }).headers["x-goog-api-key"];
  const twoKeys = (): HttpToolCtx => {
    const c = ctx();
    c.config.keys.gemini = ["k1", "k2"];
    return c;
  };

  beforeEach(() => {
    postJson.mockReset();
    quota.setStorage(null);
    quota.reset();
  });

  it("uses Gemini 2.5 even when the chosen model is a 3.x one", async () => {
    // 3.x grounding is "Not available" on the free tier: grounding with the user's model
    // (gemini-3.6-flash here) failed every search on a free Gemini key.
    postJson.mockResolvedValue(answer);
    expect((await webSearch("when is minecraft live", ctx())).ok).toBe(true);
    expect(modelOf(postJson.mock.calls[0]!)).toBe("gemini-2.5-flash");
  });

  it("tries the next key, then Flash-Lite, before giving up", async () => {
    postJson
      .mockRejectedValueOnce(new Error("HTTP 429: quota"))
      .mockRejectedValueOnce(new Error("HTTP 429: quota"))
      .mockResolvedValueOnce(answer);
    const r = await webSearch("when is minecraft live", twoKeys());
    expect(r).toMatchObject({ ok: true, summary: "Saturday 10am PT" });
    expect(postJson.mock.calls.map((c) => `${modelOf(c)}#${keyOf(c)}`)).toEqual([
      "gemini-2.5-flash#k1",
      "gemini-2.5-flash#k2",
      "gemini-2.5-flash-lite#k1",
    ]);
  });

  it("skips a key the chat ladder already found spent", async () => {
    quota.bench(
      { provider: "gemini", model: "gemini-2.5-flash", keyIndex: 0 },
      { durationMs: quota.DAY },
    );
    postJson.mockResolvedValue(answer);
    await webSearch("x", twoKeys());
    expect(keyOf(postJson.mock.calls[0]!)).toBe("k2");
  });

  it("says why when every route failed", async () => {
    postJson.mockRejectedValue(new Error("HTTP 429: quota"));
    const r = await webSearch("x", twoKeys());
    expect(r.ok).toBe(false);
    expect(r.summary).toMatch(/429/);
    expect(postJson).toHaveBeenCalledTimes(4);
  });
});

describe("webSearch — Tavily backs up Gemini grounding", () => {
  const withTavily = (gemini: string[]): HttpToolCtx => {
    const c = ctx();
    c.config.keys.gemini = gemini;
    c.config.keys.tavily = ["tvly-1"];
    return c;
  };
  const tavilyAnswer = {
    answer: "Spain won.",
    results: [
      { title: "Final report", url: "https://ex.com/a", content: "Spain beat England 2-1." },
    ],
  };
  const isTavily = (call: unknown[]) => String(call[0]).includes("api.tavily.com");

  beforeEach(() => {
    quota.setStorage(null);
    quota.reset();
  });

  it("is never called while Gemini answers", async () => {
    postJson.mockResolvedValue({ candidates: [{ content: { parts: [{ text: "42" }] } }] });
    await webSearch("x", withTavily(["k"]));
    expect(postJson.mock.calls.some(isTavily)).toBe(false);
  });

  it("answers when every Gemini key is rate-limited", async () => {
    postJson.mockImplementation(async (url: string) => {
      if (url.includes("api.tavily.com")) return tavilyAnswer;
      throw new Error("HTTP 429: quota");
    });
    const r = await webSearch("who won", withTavily(["k"]));
    expect(r.ok).toBe(true);
    expect(r.summary).toMatch(/Spain won/);
    expect(r.data).toEqual({ sources: [{ title: "Final report", uri: "https://ex.com/a" }] });
    const tavilyCall = postJson.mock.calls.find(isTavily)!;
    expect((tavilyCall[2] as { headers: Record<string, string> }).headers.Authorization).toBe(
      "Bearer tvly-1",
    );
  });

  it("answers with no Gemini key at all", async () => {
    postJson.mockResolvedValue(tavilyAnswer);
    expect((await webSearch("who won", withTavily([]))).ok).toBe(true);
  });

  it("reports both failures, never a success, when the backup fails too", async () => {
    postJson.mockRejectedValue(new Error("HTTP 432"));
    const r = await webSearch("who won", withTavily(["k"]));
    expect(r.ok).toBe(false);
    expect(r.summary).toMatch(/Tavily backup failed too/);
    expect(r.summary).toMatch(/432/);
  });
});

describe("reading a web page (research without a PC)", () => {
  const page = () =>
    new Response(
      `<title>NASA source</title><article>${"Research evidence. ".repeat(30)}</article>`,
    );

  it("reads source text and preserves the final URL after a public redirect", async () => {
    const { readWebPage } = await import("./http");
    resilientFetch
      .mockResolvedValueOnce(
        new Response(null, {
          status: 302,
          headers: { location: "https://science.nasa.gov/mission/europa-clipper/" },
        }),
      )
      .mockResolvedValueOnce(page());
    const r = await readWebPage("https://www.nasa.gov/clipper");
    expect(r.ok).toBe(true);
    expect(r.summary).toContain("Research evidence.");
    expect(r.data).toEqual({
      sources: [
        {
          title: "NASA source",
          uri: "https://science.nasa.gov/mission/europa-clipper/",
        },
      ],
    });
    expect(resilientFetch.mock.calls[0]![1]).toMatchObject({
      maxRedirections: 0,
      redirect: "manual",
      credentials: "omit",
    });
  });

  it("blocks a public page redirecting to the private network before a second request", async () => {
    const { readWebPage } = await import("./http");
    resilientFetch.mockResolvedValueOnce(
      new Response(null, {
        status: 302,
        headers: { location: "http://192.168.1.1/admin" },
      }),
    );
    expect((await readWebPage("https://example.org/source")).ok).toBe(false);
    expect(resilientFetch).toHaveBeenCalledTimes(1);
  });

  it("bounds redirect loops and reports empty or inaccessible sources as failures", async () => {
    const { readWebPage } = await import("./http");
    resilientFetch.mockImplementation(
      async () =>
        new Response(null, {
          status: 302,
          headers: { location: "/again" },
        }),
    );
    expect((await readWebPage("https://example.org/source")).summary).toContain(
      "Too many page redirects",
    );
    expect(resilientFetch).toHaveBeenCalledTimes(6);
    resilientFetch.mockResolvedValueOnce(new Response("<p>Loading...</p>"));
    expect((await readWebPage("https://example.org/empty")).ok).toBe(false);
    resilientFetch.mockResolvedValueOnce(new Response("denied", { status: 403 }));
    expect((await readWebPage("https://example.org/blocked")).summary).toContain("HTTP 403");
  });

  it("keeps the article's words, not its scripts, menus or entities", async () => {
    const { pageText } = await import("./http");
    const html =
      "<html><head><title>Pixel 8a review &amp; verdict</title><style>p{}</style></head><body>" +
      "<nav>Home | Phones</nav><script>var x = '<p>no</p>';</script>" +
      "<article><h1>The Pixel 8a</h1>" +
      `<p data-mw='{"a":"x<br />y"}'>Battery: 4,492&nbsp;mAh &#8212; lasts a day.</p></article>` +
      "<footer>© site</footer></body></html>";
    const { title, text } = pageText(html);
    expect(title).toBe("Pixel 8a review & verdict");
    expect(text).toBe("The Pixel 8a\nBattery: 4,492 mAh — lasts a day.");
  });

  it("never reads this phone's network or a non-web address", async () => {
    const { isPrivateHost, readWebPage } = await import("./http");
    for (const h of [
      "localhost",
      "192.168.0.1",
      "10.2.3.4",
      "172.20.0.1",
      "printer.local",
      "[::1]",
    ])
      expect(isPrivateHost(h)).toBe(true);
    expect(isPrivateHost("en.wikipedia.org")).toBe(false);
    expect(isPrivateHost("172.32.0.1")).toBe(false);
    await expect(readWebPage("http://192.168.0.1/admin")).resolves.toMatchObject({ ok: false });
    await expect(readWebPage("file:///sdcard/a.txt")).resolves.toMatchObject({ ok: false });
  });
});
